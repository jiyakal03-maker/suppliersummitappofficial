"use client";
import { createTheme } from "@mui/material/styles";

/** Etnyre Summit palette — mirrors the CSS variables in globals.css. */
export const tokens = {
  yellow: "#FFED00",
  yellowHover: "#F0E000",
  yellowPressed: "#DDCE00",
  yellowTint: "#FFFBD1",
  ink: "#1C1C1E",
  grey: {
    800: "#2A2A2E",
    700: "#4A4A4C",
    600: "#6B6A6C",
    500: "#8A898B",
    400: "#ABAAAC",
    300: "#C8C7C9",
    200: "#DEDEDD",
    100: "#EEEDEB",
    50: "#F7F6F3",
  },
  amber: {
    100: "#FCE9D2",
    300: "#FBB96A",
    500: "#F98719",
    700: "#C56508",
    900: "#9A5108",
  },
} as const;

const radiusControl = 10;
const radiusCard = 14;

/**
 * Conventions
 * - primary   = brand yellow. Always ink text/icons on yellow (contrast).
 * - secondary = ink. Outlined/text buttons, chips, nav emphasis.
 * - error/warning = candy-corn amber ramp (no red in this brand).
 * - success   = ink surfaces with a yellow check icon (no green in brand);
 *               palette.success is mapped to ink so MUI success props stay legal.
 */
const theme = createTheme({
  cssVariables: true,
  palette: {
    mode: "light",
    primary: { main: tokens.yellow, dark: tokens.yellowPressed, light: tokens.yellowTint, contrastText: tokens.ink },
    secondary: { main: tokens.ink, contrastText: "#FFFFFF" },
    error: { main: tokens.amber[500], dark: tokens.amber[700], light: tokens.amber[100], contrastText: tokens.ink },
    warning: { main: tokens.amber[500], dark: tokens.amber[700], light: tokens.amber[100], contrastText: tokens.ink },
    success: { main: tokens.ink, contrastText: "#FFFFFF" },
    info: { main: tokens.grey[700], contrastText: "#FFFFFF" },
    text: { primary: tokens.ink, secondary: tokens.grey[600], disabled: tokens.grey[400] },
    divider: tokens.grey[200],
    background: { default: "#FFFFFF", paper: "#FFFFFF" },
    grey: tokens.grey,
  },
  shape: { borderRadius: radiusControl },
  typography: {
    fontFamily: "var(--font-geist-sans), system-ui, -apple-system, sans-serif",
    h1: { fontSize: "1.75rem", fontWeight: 700, letterSpacing: "-0.01em" },
    h2: { fontSize: "1.375rem", fontWeight: 700, letterSpacing: "-0.01em" },
    h3: { fontSize: "1.125rem", fontWeight: 600 },
    subtitle1: { fontSize: "0.9375rem", fontWeight: 600 },
    subtitle2: { fontSize: "0.8125rem", fontWeight: 600, letterSpacing: "0.08em", textTransform: "uppercase" as const },
    body1: { fontSize: "0.9375rem", lineHeight: 1.6 },
    body2: { fontSize: "0.8125rem", lineHeight: 1.55 },
    caption: { fontSize: "0.75rem", color: tokens.grey[600] },
    button: { textTransform: "none" as const, fontWeight: 600 },
  },
  components: {
    MuiButton: {
      defaultProps: { disableElevation: true },
      styleOverrides: {
        root: {
          borderRadius: radiusControl,
          paddingInline: 18,
          minHeight: 44,
          variants: [
            {
              props: { variant: "contained", color: "primary" },
              style: {
                color: tokens.ink,
                "&:hover": { backgroundColor: tokens.yellowHover },
                "&:active": { backgroundColor: tokens.yellowPressed },
              },
            },
            {
              props: { variant: "outlined", color: "secondary" },
              style: {
                borderColor: tokens.grey[300],
                "&:hover": { borderColor: tokens.ink, backgroundColor: tokens.grey[50] },
              },
            },
            {
              props: { variant: "contained", color: "error" },
              style: {
                color: "#FFFFFF",
                backgroundColor: tokens.amber[700],
                "&:hover": { backgroundColor: tokens.amber[900] },
              },
            },
          ],
        },
      },
    },
    MuiIconButton: {
      styleOverrides: { root: { borderRadius: radiusControl } },
    },
    MuiFab: {
      defaultProps: { color: "primary" },
      styleOverrides: {
        root: {
          color: tokens.ink,
          boxShadow: "0 4px 14px rgba(28,28,30,0.22)",
          "&:hover": { backgroundColor: tokens.yellowHover },
        },
      },
    },
    MuiTextField: { defaultProps: { size: "small", fullWidth: true } },
    MuiOutlinedInput: {
      styleOverrides: {
        root: {
          borderRadius: radiusControl,
          backgroundColor: "#FFFFFF",
          "&:hover .MuiOutlinedInput-notchedOutline": { borderColor: tokens.grey[500] },
          "&.Mui-focused .MuiOutlinedInput-notchedOutline": { borderColor: tokens.ink, borderWidth: 2 },
        },
        notchedOutline: { borderColor: tokens.grey[300] },
      },
    },
    MuiInputLabel: {
      styleOverrides: { root: { "&.Mui-focused": { color: tokens.ink } } },
    },
    MuiChip: {
      styleOverrides: {
        root: { fontWeight: 600, borderRadius: 999 },
        colorPrimary: { color: tokens.ink },
      },
    },
    MuiSwitch: {
      styleOverrides: {
        root: {
          "& .MuiSwitch-switchBase.Mui-checked": { color: tokens.yellow },
          "& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track": { backgroundColor: tokens.ink, opacity: 1 },
          "& .MuiSwitch-switchBase.Mui-checked .MuiSwitch-thumb": { border: `1px solid ${tokens.ink}` },
        },
      },
    },
    MuiCheckbox: {
      styleOverrides: { root: { color: tokens.grey[400], "&.Mui-checked": { color: tokens.ink } } },
    },
    MuiRadio: {
      styleOverrides: { root: { color: tokens.grey[400], "&.Mui-checked": { color: tokens.ink } } },
    },
    MuiTabs: {
      styleOverrides: {
        indicator: { backgroundColor: tokens.yellow, height: 3, borderRadius: 3 },
      },
    },
    MuiTab: {
      styleOverrides: {
        root: { textTransform: "none", fontWeight: 600, "&.Mui-selected": { color: tokens.ink } },
      },
    },
    MuiLinearProgress: {
      styleOverrides: {
        root: { height: 8, borderRadius: 999, backgroundColor: tokens.grey[100] },
        bar: { borderRadius: 999, backgroundColor: tokens.yellow },
      },
    },
    MuiCircularProgress: {
      styleOverrides: { colorPrimary: { color: tokens.ink } },
    },
    MuiDialog: {
      styleOverrides: { paper: { borderRadius: radiusCard, padding: 4 } },
    },
    MuiPaper: {
      styleOverrides: { rounded: { borderRadius: radiusCard } },
    },
    MuiCard: {
      styleOverrides: {
        root: { borderRadius: radiusCard, border: `1px solid ${tokens.grey[200]}`, boxShadow: "none" },
      },
    },
    MuiAlert: {
      styleOverrides: {
        root: {
          borderRadius: radiusControl,
          variants: [
            {
              props: { severity: "error", variant: "standard" },
              style: { backgroundColor: tokens.amber[100], color: tokens.amber[900], "& .MuiAlert-icon": { color: tokens.amber[700] } },
            },
            {
              props: { severity: "warning", variant: "standard" },
              style: { backgroundColor: tokens.amber[100], color: tokens.amber[900], "& .MuiAlert-icon": { color: tokens.amber[700] } },
            },
            {
              props: { severity: "success", variant: "standard" },
              style: { backgroundColor: tokens.grey[800], color: "#FFFFFF", "& .MuiAlert-icon": { color: tokens.yellow } },
            },
            {
              props: { severity: "info", variant: "standard" },
              style: { backgroundColor: tokens.grey[100], color: tokens.ink, "& .MuiAlert-icon": { color: tokens.grey[700] } },
            },
          ],
        },
      },
    },
    MuiStepIcon: {
      styleOverrides: {
        root: {
          color: tokens.grey[200],
          "&.Mui-active": { color: tokens.yellow, "& .MuiStepIcon-text": { fill: tokens.ink } },
          "&.Mui-completed": { color: tokens.ink },
        },
        text: { fill: tokens.grey[600], fontWeight: 700 },
      },
    },
    MuiBottomNavigation: {
      styleOverrides: { root: { borderTop: `1px solid ${tokens.grey[200]}` } },
    },
    MuiBottomNavigationAction: {
      styleOverrides: {
        root: { color: tokens.grey[500], "&.Mui-selected": { color: tokens.ink } },
      },
    },
    MuiAppBar: {
      defaultProps: { elevation: 0, color: "transparent" },
      styleOverrides: { root: { backgroundColor: "#FFFFFF", borderBottom: `1px solid ${tokens.grey[200]}` } },
    },
    MuiAvatar: {
      styleOverrides: { root: { backgroundColor: tokens.grey[100], color: tokens.ink, fontWeight: 600 } },
    },
    MuiSkeleton: {
      styleOverrides: { root: { backgroundColor: tokens.grey[100] } },
    },
    MuiTooltip: {
      styleOverrides: { tooltip: { backgroundColor: tokens.ink, fontSize: "0.75rem" } },
    },
  },
});

export default theme;
